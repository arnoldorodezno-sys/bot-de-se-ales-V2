# 📡 Bot de Señales SMC v2

Bot que analiza el mercado de Binance Futures con 7 filtros SMC profesionales y envía señales de calidad a Telegram.

## ⚡ Características

- ✅ Analiza 10 criptomonedas cada 60 segundos
- ✅ 7 filtros SMC (Smart Money Concepts)
- ✅ Score 0-10 para cada señal
- ✅ Stop Loss y Take Profit automáticos
- ✅ Envía a Telegram con formato profesional
- ✅ **NO abre operaciones** (solo alertas)
- ✅ Funciona 24/7 en Railway
- ✅ Manejo de errores robusto

## 🚀 Instalación

### 1. Configurar credenciales

```bash
cp .env.example .env
```

Edita `.env` y coloca:
- `BINANCE_API_KEY` - Tu API Key (solo permiso LECTURA)
- `BINANCE_API_SECRET` - Tu API Secret
- `TELEGRAM_BOT_TOKEN` - Token de @BotFather (formato: `123456789:ABC...`)
- `TELEGRAM_CHAT_ID` - Tu ID (de @userinfobot)

### 2. Local (Windows)

Doble clic en `iniciar_señales.bat`

### 3. Railway (24/7)

1. Sube el proyecto a GitHub
2. Crea un proyecto en Railway
3. Conecta el repositorio
4. Agrega las variables de entorno en Railway → Variables
5. Railway desplegará automáticamente

## ⚙️ Configuración

Edita `signal_config.py` para ajustar:

| Parámetro | Por defecto | Significado |
|-----------|-------------|-------------|
| `SCORE_MIN_SIGNAL` | 5.0 | Score mínimo para enviar señal |
| `MIN_RR` | 1.8 | Ratio Riesgo:Recompensa mínimo |
| `MAX_SL_PCT` | 0.02 | Stop Loss máximo (2%) |
| `SIGNAL_COOLDOWN_MINUTES` | 240 | Tiempo entre señales del mismo símbolo |
| `LOOP_INTERVAL_SECONDS` | 60 | Cada cuánto analiza |

## 📊 Los 7 Filtros SMC

1. **Tendencia principal** (EMA 200)
2. **Liquidity Sweep** (barrido de liquidez)
3. **Order Block** (bloque de órdenes)
4. **Break of Structure** (BOS)
5. **Fair Value Gap** (FVG)
6. **RSI** (no sobrecomprado/sobrevendido)
7. **Volumen confirmado**

## 📱 Formato del Mensaje

```
🟢 LONG | BTCUSDT
━━━━━━━━━━━━━━━━━━━━━
⭐ SEÑAL EXCELENTE
📊 Score: 8.5/10

💰 Entrada: $62,450.00
🛑 Stop Loss: $61,800.00 (-1.04%)
🎯 TP1: $63,100.00 (+1.04%)
🎯 TP2: $63,750.00 (+2.08%)

📐 R:R → 1:2.0
🔗 Confluencias: TENDENCIA + SWEEP + OB + BOS + RSI

🕐 2026-05-12 10:30 UTC
⚠️ Solo análisis técnico. No es consejo financiero.
```

## ⚠️ Aviso Importante

- Este bot **NO opera** en Binance, solo envía alertas
- Las señales son **solo análisis técnico**
- **No es consejo financiero**
- Usa bajo tu propia responsabilidad
