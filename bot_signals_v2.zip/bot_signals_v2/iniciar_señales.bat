@echo off
chcp 65001 >nul
title Bot de Senales SMC v2

echo ════════════════════════════════════════════════════════════
echo    BOT DE SENALES SMC v2 - INICIANDO
echo ════════════════════════════════════════════════════════════
echo.

REM Verificar Python
where python >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python no esta instalado o no esta en PATH
    echo Descarga Python desde: https://www.python.org/downloads/
    pause
    exit /b 1
)

REM Crear entorno virtual si no existe
if not exist "venv\" (
    echo Creando entorno virtual...
    python -m venv venv
    echo.
)

REM Activar entorno virtual
echo Activando entorno virtual...
call venv\Scripts\activate

REM Instalar dependencias si es necesario
if not exist "venv\Scripts\pip.exe" (
    echo ERROR: Entorno virtual no se creo correctamente
    pause
    exit /b 1
)

echo Verificando dependencias...
pip install -q -r requirements.txt

echo.
echo ════════════════════════════════════════════════════════════
echo    BOT INICIANDO - Presiona Ctrl+C para detener
echo ════════════════════════════════════════════════════════════
echo.

REM Ejecutar el bot
python signal_main.py

REM Si el bot se detiene, pausar
echo.
echo Bot detenido.
pause
