"""
═══════════════════════════════════════════════════════════════════
   BOT DE SEÑALES SMC v2 - ARCHIVO PRINCIPAL
═══════════════════════════════════════════════════════════════════
   
   Este es el bot principal. Lo que hace:
   
   1. Conecta a Binance (solo lectura, NO opera)
   2. Cada 60 segundos analiza 10 símbolos
   3. Aplica 7 filtros SMC profesionales
   4. Si encuentra señal de calidad → Envía a Telegram
   5. Reintentos automáticos si hay errores
   6. Logs claros en consola
   
   El bot NUNCA abre operaciones.
   Solo necesita permisos de LECTURA en la API Key.
═══════════════════════════════════════════════════════════════════
"""

import os
import sys
import time
import logging
import signal as sys_signal
from datetime import datetime, timedelta
from typing import Dict, Optional

# Cargar variables de entorno
from dotenv import load_dotenv
load_dotenv()

# Configurar logging ANTES de imports propios
import signal_config as cfg

logging.basicConfig(
    level=getattr(logging, cfg.LOG_LEVEL, logging.INFO),
    format='%(asctime)s | %(levelname)-7s | %(name)-25s | %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("SignalBot")

# Imports después del logging
import pandas as pd
from binance.client import Client
from binance.exceptions import BinanceAPIException
from apscheduler.schedulers.background import BackgroundScheduler

import signal_analyzer as analyzer
from signal_telegram import TelegramNotifier


class SignalBot:
    """Bot principal de señales SMC"""
    
    def __init__(self):
        # Cargar credenciales
        self.api_key = os.getenv('BINANCE_API_KEY', '').strip()
        self.api_secret = os.getenv('BINANCE_API_SECRET', '').strip()
        self.telegram_token = os.getenv('TELEGRAM_BOT_TOKEN', '').strip()
        self.telegram_chat_id = os.getenv('TELEGRAM_CHAT_ID', '').strip()
        
        # Validar credenciales
        self._validate_credentials()
        
        # Conectar a Binance
        self.client = self._connect_binance()
        
        # Conectar a Telegram
        self.telegram = TelegramNotifier(self.telegram_token, self.telegram_chat_id)
        
        # Estado del bot
        self.last_signals: Dict[str, datetime] = {}  # symbol -> última señal
        self.daily_signals_count = 0
        self.daily_analyzed_count = 0
        self.running = True
        
        # Scheduler para tareas periódicas
        self.scheduler = BackgroundScheduler()
        
        logger.info("=" * 60)
        logger.info("🚀 BOT DE SEÑALES SMC v2 - INICIANDO")
        logger.info("=" * 60)
        logger.info(f"📊 Símbolos: {len(cfg.SYMBOLS)}")
        logger.info(f"⭐ Score mínimo: {cfg.SCORE_MIN_SIGNAL}/10")
        logger.info(f"📐 R:R mínimo: 1:{cfg.MIN_RR}")
        logger.info(f"⏱️ Loop: cada {cfg.LOOP_INTERVAL_SECONDS}s")
        logger.info(f"⏰ Cooldown: {cfg.SIGNAL_COOLDOWN_MINUTES} minutos")
        logger.info("=" * 60)
    
    def _validate_credentials(self):
        """Valida que todas las credenciales estén configuradas"""
        missing = []
        if not self.api_key:
            missing.append("BINANCE_API_KEY")
        if not self.api_secret:
            missing.append("BINANCE_API_SECRET")
        if not self.telegram_token:
            logger.warning("⚠️ TELEGRAM_BOT_TOKEN no configurado")
        if not self.telegram_chat_id:
            logger.warning("⚠️ TELEGRAM_CHAT_ID no configurado")
        
        if missing:
            logger.error(f"❌ Faltan credenciales: {', '.join(missing)}")
            logger.error("Configura las variables en .env o Railway")
            sys.exit(1)
        
        # Validar formato del token de Telegram
        if self.telegram_token:
            if ':' not in self.telegram_token:
                logger.error(f"❌ TELEGRAM_BOT_TOKEN parece inválido (sin ':')")
                logger.error(f"   Token actual: {self.telegram_token[:20]}...")
                logger.error(f"   Debe ser formato: 123456789:ABCdefGHIjkl...")
            else:
                logger.info(f"✅ Token Telegram: {self.telegram_token[:15]}...")
    
    def _connect_binance(self) -> Client:
        """Conecta a Binance con reintentos"""
        for attempt in range(1, cfg.MAX_RETRIES + 1):
            try:
                logger.info(f"🔌 Conectando a Binance (intento {attempt})...")
                client = Client(self.api_key, self.api_secret)
                # Test de conexión
                server_time = client.get_server_time()
                logger.info(f"✅ Conectado a Binance (server time: {server_time['serverTime']})")
                return client
            except BinanceAPIException as e:
                logger.error(f"❌ Error API Binance: {e}")
                if "Invalid API-key" in str(e):
                    logger.error("   → Verifica que la API Key tenga permisos de LECTURA")
                    logger.error("   → Verifica que la IP esté permitida")
                if attempt < cfg.MAX_RETRIES:
                    time.sleep(cfg.RETRY_DELAY_SECONDS)
            except Exception as e:
                logger.error(f"❌ Error conectando a Binance: {e}")
                if attempt < cfg.MAX_RETRIES:
                    time.sleep(cfg.RETRY_DELAY_SECONDS)
        
        logger.error("❌ No se pudo conectar a Binance")
        sys.exit(1)
    
    def get_klines(self, symbol: str, interval: str, limit: int = None) -> Optional[pd.DataFrame]:
        """Obtiene velas históricas de Binance"""
        if limit is None:
            limit = cfg.CANDLES_LIMIT
        
        for attempt in range(1, cfg.MAX_RETRIES + 1):
            try:
                klines = self.client.get_klines(
                    symbol=symbol,
                    interval=interval,
                    limit=limit
                )
                
                if not klines:
                    return None
                
                df = pd.DataFrame(klines, columns=[
                    'timestamp', 'open', 'high', 'low', 'close', 'volume',
                    'close_time', 'quote_volume', 'trades', 'taker_buy_base',
                    'taker_buy_quote', 'ignore'
                ])
                
                # Convertir tipos
                for col in ['open', 'high', 'low', 'close', 'volume']:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
                
                df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
                
                return df
                
            except BinanceAPIException as e:
                logger.warning(f"⚠️ Error API obteniendo {symbol} {interval} (intento {attempt}): {e}")
                if attempt < cfg.MAX_RETRIES:
                    time.sleep(cfg.RETRY_DELAY_SECONDS)
            except Exception as e:
                logger.warning(f"⚠️ Error obteniendo {symbol} {interval}: {e}")
                if attempt < cfg.MAX_RETRIES:
                    time.sleep(cfg.RETRY_DELAY_SECONDS)
        
        return None
    
    def can_send_signal(self, symbol: str) -> bool:
        """Verifica si se puede enviar señal (respetando cooldown)"""
        if symbol not in self.last_signals:
            return True
        
        last_time = self.last_signals[symbol]
        elapsed = datetime.utcnow() - last_time
        cooldown = timedelta(minutes=cfg.SIGNAL_COOLDOWN_MINUTES)
        
        return elapsed >= cooldown
    
    def analyze_all_symbols(self):
        """Analiza todos los símbolos buscando señales"""
        logger.info(f"🔍 Analizando {len(cfg.SYMBOLS)} símbolos...")
        signals_found = 0
        symbols_analyzed = 0
        
        for symbol in cfg.SYMBOLS:
            try:
                # Verificar cooldown
                if not self.can_send_signal(symbol):
                    logger.debug(f"⏰ {symbol}: en cooldown, saltando")
                    continue
                
                # Obtener velas
                df_main = self.get_klines(symbol, cfg.TIMEFRAME_MAIN)
                df_confirm = self.get_klines(symbol, cfg.TIMEFRAME_CONFIRM)
                
                if df_main is None or df_confirm is None:
                    logger.warning(f"⚠️ {symbol}: no se pudieron obtener velas")
                    continue
                
                symbols_analyzed += 1
                
                # Analizar
                signal = analyzer.analyze_symbol(df_main, df_confirm)
                
                if signal:
                    logger.info(
                        f"🎯 SEÑAL: {symbol} {signal['direction']} | "
                        f"Score: {signal['score']}/10 | "
                        f"Filtros: {signal['filters_passed']}/7 | "
                        f"R:R: 1:{signal['rr']}"
                    )
                    
                    # Enviar a Telegram
                    sent = self.telegram.send_signal(symbol, signal)
                    if sent:
                        self.last_signals[symbol] = datetime.utcnow()
                        self.daily_signals_count += 1
                        signals_found += 1
                        logger.info(f"✅ Señal enviada: {symbol}")
                    else:
                        logger.error(f"❌ Error enviando señal: {symbol}")
                else:
                    logger.debug(f"   {symbol}: sin señal en este ciclo")
                
            except Exception as e:
                logger.error(f"❌ Error con {symbol}: {e}", exc_info=True)
                continue
        
        self.daily_analyzed_count = symbols_analyzed
        
        if signals_found == 0:
            logger.info(f"   Sin señales de calidad (analizados: {symbols_analyzed}/{len(cfg.SYMBOLS)})")
        else:
            logger.info(f"✅ Ciclo completo: {signals_found} señal(es) enviada(s)")
    
    def send_daily_summary(self):
        """Envía resumen diario y resetea contadores"""
        try:
            if cfg.ENABLE_DAILY_SUMMARY:
                logger.info("📅 Enviando resumen diario...")
                self.telegram.send_daily_summary(
                    self.daily_signals_count,
                    len(cfg.SYMBOLS)
                )
            # Resetear contadores
            self.daily_signals_count = 0
            self.daily_analyzed_count = 0
        except Exception as e:
            logger.error(f"Error en resumen diario: {e}")
    
    def start(self):
        """Inicia el bot"""
        try:
            # Mensaje de inicio en Telegram
            self.telegram.send_startup(len(cfg.SYMBOLS))
            
            # Programar resumen diario
            if cfg.ENABLE_DAILY_SUMMARY:
                self.scheduler.add_job(
                    self.send_daily_summary,
                    'cron',
                    hour=cfg.DAILY_SUMMARY_HOUR_UTC,
                    minute=0
                )
                self.scheduler.start()
                logger.info(f"📅 Resumen diario programado a las {cfg.DAILY_SUMMARY_HOUR_UTC}:00 UTC")
            
            # Manejadores de señales del sistema
            sys_signal.signal(sys_signal.SIGINT, self._stop_handler)
            sys_signal.signal(sys_signal.SIGTERM, self._stop_handler)
            
            logger.info("✅ Bot iniciado correctamente. Esperando señales...")
            logger.info("=" * 60)
            
            # Loop principal
            while self.running:
                try:
                    cycle_start = time.time()
                    self.analyze_all_symbols()
                    
                    # Calcular tiempo restante hasta el próximo ciclo
                    elapsed = time.time() - cycle_start
                    sleep_time = max(0, cfg.LOOP_INTERVAL_SECONDS - elapsed)
                    
                    if sleep_time > 0:
                        logger.debug(f"💤 Esperando {sleep_time:.1f}s hasta el próximo ciclo...")
                        time.sleep(sleep_time)
                        
                except KeyboardInterrupt:
                    self.running = False
                    break
                except Exception as e:
                    logger.error(f"❌ Error en loop principal: {e}", exc_info=True)
                    try:
                        self.telegram.send_error(str(e))
                    except:
                        pass
                    time.sleep(cfg.RETRY_DELAY_SECONDS)
            
        except Exception as e:
            logger.error(f"❌ Error fatal: {e}", exc_info=True)
        finally:
            self._cleanup()
    
    def _stop_handler(self, signum, frame):
        """Maneja señales de parada del sistema"""
        logger.info(f"🛑 Recibida señal {signum}, deteniendo bot...")
        self.running = False
    
    def _cleanup(self):
        """Limpia recursos antes de cerrar"""
        logger.info("🧹 Limpiando recursos...")
        try:
            if self.scheduler.running:
                self.scheduler.shutdown(wait=False)
        except:
            pass
        logger.info("👋 Bot detenido")


def main():
    """Punto de entrada principal"""
    try:
        bot = SignalBot()
        bot.start()
    except KeyboardInterrupt:
        logger.info("👋 Bot detenido por usuario")
    except Exception as e:
        logger.error(f"❌ Error fatal: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
