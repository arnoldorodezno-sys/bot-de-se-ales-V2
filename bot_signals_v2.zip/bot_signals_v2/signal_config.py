"""
═══════════════════════════════════════════════════════════════════
   CONFIGURACIÓN DEL BOT DE SEÑALES SMC v2
═══════════════════════════════════════════════════════════════════
   Aquí puedes modificar todos los parámetros del bot.
   Después de cambiar algo, sube a GitHub y Railway redesplegará.
═══════════════════════════════════════════════════════════════════
"""

# ═══════════════════════════════════════════════════════════════════
# SÍMBOLOS A MONITOREAR (10 criptomonedas)
# ═══════════════════════════════════════════════════════════════════
SYMBOLS = [
    "BTCUSDT",
    "ETHUSDT",
    "BNBUSDT",
    "SOLUSDT",
    "XRPUSDT",
    "ADAUSDT",
    "LTCUSDT",
    "DOTUSDT",
    "AVAXUSDT",
    "LINKUSDT",
]

# ═══════════════════════════════════════════════════════════════════
# TIMEFRAMES (Marcos temporales)
# ═══════════════════════════════════════════════════════════════════
TIMEFRAME_MAIN = "15m"      # Timeframe principal para señales
TIMEFRAME_CONFIRM = "1h"    # Timeframe de confirmación de tendencia

# ═══════════════════════════════════════════════════════════════════
# FILTROS DE CALIDAD (Ajustables)
# ═══════════════════════════════════════════════════════════════════

# Score mínimo para enviar señal (0-10)
# 4.0 = Muchas señales (menos calidad)
# 5.0 = Balance recomendado
# 6.0 = Pocas señales (más calidad)
# 7.0 = Solo señales perfectas
SCORE_MIN_SIGNAL = 5.0

# Ratio Riesgo:Recompensa mínimo
# 1.5 = Conservador (más señales)
# 2.0 = Estándar
# 3.0 = Solo trades muy buenos
MIN_RR = 1.8

# Stop Loss máximo (% del precio de entrada)
# 0.01 = 1% máximo de riesgo
# 0.02 = 2% máximo (recomendado)
# 0.03 = 3% máximo (más riesgo)
MAX_SL_PCT = 0.02

# ═══════════════════════════════════════════════════════════════════
# COOLDOWN (Para no spamear señales del mismo símbolo)
# ═══════════════════════════════════════════════════════════════════
SIGNAL_COOLDOWN_MINUTES = 240  # 4 horas entre señales del mismo símbolo

# ═══════════════════════════════════════════════════════════════════
# LOOP DE ANÁLISIS
# ═══════════════════════════════════════════════════════════════════
LOOP_INTERVAL_SECONDS = 60  # Analiza cada 60 segundos

# ═══════════════════════════════════════════════════════════════════
# INDICADORES TÉCNICOS
# ═══════════════════════════════════════════════════════════════════
EMA_TREND_PERIOD = 200      # EMA para tendencia principal
EMA_FAST_PERIOD = 21        # EMA rápida
EMA_SLOW_PERIOD = 50        # EMA lenta
RSI_PERIOD = 14             # Período RSI
RSI_OVERBOUGHT = 70         # Nivel sobrecomprado
RSI_OVERSOLD = 30           # Nivel sobrevendido
VOLUME_MA_PERIOD = 20       # Promedio de volumen

# ═══════════════════════════════════════════════════════════════════
# CONFIGURACIÓN AVANZADA
# ═══════════════════════════════════════════════════════════════════
CANDLES_LIMIT = 200         # Cuántas velas analizar por símbolo
SWEEP_LOOKBACK = 20         # Velas a revisar para liquidity sweep
OB_LOOKBACK = 10            # Velas a revisar para order block
FVG_LOOKBACK = 30           # Velas a revisar para fair value gap

# ═══════════════════════════════════════════════════════════════════
# REINTENTOS Y TIMEOUTS
# ═══════════════════════════════════════════════════════════════════
MAX_RETRIES = 3             # Reintentos al fallar API
RETRY_DELAY_SECONDS = 5     # Espera entre reintentos
TELEGRAM_TIMEOUT = 30       # Timeout para enviar mensajes Telegram

# ═══════════════════════════════════════════════════════════════════
# RESUMEN DIARIO
# ═══════════════════════════════════════════════════════════════════
DAILY_SUMMARY_HOUR_UTC = 0  # Hora UTC para enviar resumen diario (0 = medianoche)
ENABLE_DAILY_SUMMARY = True

# ═══════════════════════════════════════════════════════════════════
# LOGS
# ═══════════════════════════════════════════════════════════════════
LOG_LEVEL = "INFO"          # DEBUG, INFO, WARNING, ERROR
