"""
═══════════════════════════════════════════════════════════════════
   ANALIZADOR SMC (Smart Money Concepts)
═══════════════════════════════════════════════════════════════════
   Analiza el mercado aplicando 7 filtros profesionales:
   
   1. Tendencia principal (EMA 200)
   2. Liquidity Sweep (barrido de liquidez)
   3. Order Block (bloque de órdenes)
   4. Break of Structure (BOS/CHOCH)
   5. Fair Value Gap (FVG)
   6. RSI (no sobrecomprado/sobrevendido)
   7. Volumen confirmado
   
   Cada filtro vale ~1.43 puntos. Score total: 0-10
═══════════════════════════════════════════════════════════════════
"""

import logging
import pandas as pd
import numpy as np
from typing import Optional, Dict, Tuple
import signal_config as cfg

logger = logging.getLogger(__name__)


def calculate_ema(series: pd.Series, period: int) -> pd.Series:
    """Calcula EMA (Exponential Moving Average)"""
    return series.ewm(span=period, adjust=False).mean()


def calculate_rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """Calcula RSI (Relative Strength Index)"""
    delta = series.diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi


def detect_trend(df: pd.DataFrame) -> str:
    """
    FILTRO 1: Detecta tendencia principal usando EMA 200
    Retorna: 'BULLISH', 'BEARISH', o 'NEUTRAL'
    """
    try:
        ema_200 = calculate_ema(df['close'], cfg.EMA_TREND_PERIOD)
        ema_21 = calculate_ema(df['close'], cfg.EMA_FAST_PERIOD)
        ema_50 = calculate_ema(df['close'], cfg.EMA_SLOW_PERIOD)
        
        current_price = df['close'].iloc[-1]
        ema_200_current = ema_200.iloc[-1]
        ema_21_current = ema_21.iloc[-1]
        ema_50_current = ema_50.iloc[-1]
        
        # Tendencia alcista: precio > EMA200, EMA21 > EMA50
        if current_price > ema_200_current and ema_21_current > ema_50_current:
            return 'BULLISH'
        # Tendencia bajista: precio < EMA200, EMA21 < EMA50
        elif current_price < ema_200_current and ema_21_current < ema_50_current:
            return 'BEARISH'
        else:
            return 'NEUTRAL'
    except Exception as e:
        logger.warning(f"Error en detect_trend: {e}")
        return 'NEUTRAL'


def detect_liquidity_sweep(df: pd.DataFrame, direction: str) -> bool:
    """
    FILTRO 2: Detecta Liquidity Sweep (barrido de liquidez)
    LONG: precio rompe mínimo previo y regresa
    SHORT: precio rompe máximo previo y regresa
    """
    try:
        lookback = cfg.SWEEP_LOOKBACK
        recent = df.tail(lookback)
        
        if direction == 'LONG':
            # Buscar mínimo previo y verificar si fue barrido y recuperado
            prev_low = recent['low'].iloc[:-3].min()
            recent_low = recent['low'].iloc[-3:].min()
            current_close = recent['close'].iloc[-1]
            
            # Sweep: rompió el mínimo y cerró por arriba
            if recent_low < prev_low and current_close > prev_low:
                return True
        elif direction == 'SHORT':
            # Buscar máximo previo y verificar si fue barrido y rechazado
            prev_high = recent['high'].iloc[:-3].max()
            recent_high = recent['high'].iloc[-3:].max()
            current_close = recent['close'].iloc[-1]
            
            # Sweep: rompió el máximo y cerró por debajo
            if recent_high > prev_high and current_close < prev_high:
                return True
        return False
    except Exception as e:
        logger.warning(f"Error en detect_liquidity_sweep: {e}")
        return False


def detect_order_block(df: pd.DataFrame, direction: str) -> bool:
    """
    FILTRO 3: Detecta Order Block (bloque de órdenes)
    Vela con alto volumen que origina un movimiento fuerte
    """
    try:
        lookback = cfg.OB_LOOKBACK
        recent = df.tail(lookback)
        avg_volume = recent['volume'].mean()
        
        # Buscar vela con volumen 1.5x mayor al promedio
        for i in range(len(recent) - 3, len(recent) - 1):
            if i < 0:
                continue
            vol = recent['volume'].iloc[i]
            if vol > avg_volume * 1.5:
                candle_open = recent['open'].iloc[i]
                candle_close = recent['close'].iloc[i]
                
                if direction == 'LONG' and candle_close > candle_open:
                    return True
                elif direction == 'SHORT' and candle_close < candle_open:
                    return True
        return False
    except Exception as e:
        logger.warning(f"Error en detect_order_block: {e}")
        return False


def detect_break_of_structure(df: pd.DataFrame, direction: str) -> bool:
    """
    FILTRO 4: Detecta Break of Structure (BOS)
    LONG: precio rompe último máximo significativo
    SHORT: precio rompe último mínimo significativo
    """
    try:
        recent = df.tail(50)
        current_close = recent['close'].iloc[-1]
        
        if direction == 'LONG':
            # Encontrar el último high antes de las últimas 5 velas
            prev_high = recent['high'].iloc[:-5].max()
            if current_close > prev_high:
                return True
        elif direction == 'SHORT':
            # Encontrar el último low antes de las últimas 5 velas
            prev_low = recent['low'].iloc[:-5].min()
            if current_close < prev_low:
                return True
        return False
    except Exception as e:
        logger.warning(f"Error en detect_break_of_structure: {e}")
        return False


def detect_fair_value_gap(df: pd.DataFrame, direction: str) -> bool:
    """
    FILTRO 5: Detecta Fair Value Gap (FVG)
    Gap entre 3 velas consecutivas
    """
    try:
        lookback = cfg.FVG_LOOKBACK
        recent = df.tail(lookback)
        
        # Revisar las últimas 15 velas en busca de FVG
        for i in range(len(recent) - 15, len(recent) - 2):
            if i < 1:
                continue
            
            candle1_high = recent['high'].iloc[i - 1]
            candle1_low = recent['low'].iloc[i - 1]
            candle3_high = recent['high'].iloc[i + 1]
            candle3_low = recent['low'].iloc[i + 1]
            
            if direction == 'LONG':
                # FVG alcista: low de vela 3 > high de vela 1
                if candle3_low > candle1_high:
                    return True
            elif direction == 'SHORT':
                # FVG bajista: high de vela 3 < low de vela 1
                if candle3_high < candle1_low:
                    return True
        return False
    except Exception as e:
        logger.warning(f"Error en detect_fair_value_gap: {e}")
        return False


def check_rsi(df: pd.DataFrame, direction: str) -> bool:
    """
    FILTRO 6: Verifica RSI (no sobrecomprado/sobrevendido)
    LONG: RSI no debe estar > 70 (sobrecomprado)
    SHORT: RSI no debe estar < 30 (sobrevendido)
    """
    try:
        rsi = calculate_rsi(df['close'], cfg.RSI_PERIOD)
        current_rsi = rsi.iloc[-1]
        
        if pd.isna(current_rsi):
            return False
        
        if direction == 'LONG':
            return current_rsi < cfg.RSI_OVERBOUGHT
        elif direction == 'SHORT':
            return current_rsi > cfg.RSI_OVERSOLD
        return False
    except Exception as e:
        logger.warning(f"Error en check_rsi: {e}")
        return False


def check_volume(df: pd.DataFrame) -> bool:
    """
    FILTRO 7: Verifica volumen confirmado
    El volumen actual debe ser mayor al promedio
    """
    try:
        volume_ma = df['volume'].rolling(window=cfg.VOLUME_MA_PERIOD).mean()
        current_volume = df['volume'].iloc[-1]
        avg_volume = volume_ma.iloc[-1]
        
        if pd.isna(avg_volume):
            return False
        
        # Volumen actual >= 1.2x el promedio
        return current_volume >= avg_volume * 1.2
    except Exception as e:
        logger.warning(f"Error en check_volume: {e}")
        return False


def analyze_symbol(df_main: pd.DataFrame, df_confirm: pd.DataFrame) -> Optional[Dict]:
    """
    Analiza un símbolo aplicando los 7 filtros SMC.
    Retorna dict con señal o None si no hay setup válido.
    """
    try:
        if len(df_main) < 50 or len(df_confirm) < 50:
            return None
        
        # Detectar tendencia en TF de confirmación (1h)
        trend_confirm = detect_trend(df_confirm)
        # Detectar tendencia en TF principal (15m)
        trend_main = detect_trend(df_main)
        
        # Determinar dirección posible
        direction = None
        if trend_confirm == 'BULLISH' and trend_main in ['BULLISH', 'NEUTRAL']:
            direction = 'LONG'
        elif trend_confirm == 'BEARISH' and trend_main in ['BEARISH', 'NEUTRAL']:
            direction = 'SHORT'
        else:
            return None
        
        # Aplicar los 7 filtros
        filters = {
            'tendencia': trend_confirm in ['BULLISH', 'BEARISH'],
            'sweep': detect_liquidity_sweep(df_main, direction),
            'order_block': detect_order_block(df_main, direction),
            'bos': detect_break_of_structure(df_main, direction),
            'fvg': detect_fair_value_gap(df_main, direction),
            'rsi': check_rsi(df_main, direction),
            'volumen': check_volume(df_main),
        }
        
        # Calcular score (0-10)
        passed = sum(filters.values())
        score = (passed / 7) * 10
        
        # Si no llega al score mínimo, descartar
        if score < cfg.SCORE_MIN_SIGNAL:
            return None
        
        # Calcular precios
        current_price = df_main['close'].iloc[-1]
        atr = (df_main['high'] - df_main['low']).tail(14).mean()
        
        if direction == 'LONG':
            sl_distance = min(atr * 1.5, current_price * cfg.MAX_SL_PCT)
            sl = current_price - sl_distance
            tp1 = current_price + (sl_distance * cfg.MIN_RR)
            tp2 = current_price + (sl_distance * cfg.MIN_RR * 2)
        else:  # SHORT
            sl_distance = min(atr * 1.5, current_price * cfg.MAX_SL_PCT)
            sl = current_price + sl_distance
            tp1 = current_price - (sl_distance * cfg.MIN_RR)
            tp2 = current_price - (sl_distance * cfg.MIN_RR * 2)
        
        # Calcular R:R real
        if direction == 'LONG':
            rr = abs(tp1 - current_price) / abs(current_price - sl)
        else:
            rr = abs(current_price - tp1) / abs(sl - current_price)
        
        # Lista de confluencias
        confluences = []
        if filters['tendencia']:
            confluences.append('TENDENCIA')
        if filters['sweep']:
            confluences.append('SWEEP')
        if filters['order_block']:
            confluences.append('OB')
        if filters['bos']:
            confluences.append('BOS')
        if filters['fvg']:
            confluences.append('FVG')
        if filters['rsi']:
            confluences.append('RSI')
        if filters['volumen']:
            confluences.append('VOL')
        
        return {
            'direction': direction,
            'score': round(score, 1),
            'entry': round(current_price, 4),
            'sl': round(sl, 4),
            'tp1': round(tp1, 4),
            'tp2': round(tp2, 4),
            'rr': round(rr, 2),
            'sl_pct': round(abs(current_price - sl) / current_price * 100, 2),
            'tp1_pct': round(abs(tp1 - current_price) / current_price * 100, 2),
            'tp2_pct': round(abs(tp2 - current_price) / current_price * 100, 2),
            'confluences': confluences,
            'filters_passed': passed,
        }
        
    except Exception as e:
        logger.error(f"Error analizando símbolo: {e}", exc_info=True)
        return None
