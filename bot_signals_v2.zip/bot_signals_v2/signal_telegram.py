"""
═══════════════════════════════════════════════════════════════════
   MÓDULO TELEGRAM
═══════════════════════════════════════════════════════════════════
   Envía mensajes a Telegram de forma robusta.
   - Reintentos automáticos
   - Manejo de errores
   - Logs detallados
═══════════════════════════════════════════════════════════════════
"""

import logging
import requests
import time
from typing import Optional
import signal_config as cfg

logger = logging.getLogger(__name__)


class TelegramNotifier:
    """Maneja el envío de mensajes a Telegram"""
    
    def __init__(self, bot_token: str, chat_id: str):
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.api_url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        self.enabled = bool(bot_token and chat_id)
        
        if not self.enabled:
            logger.warning("⚠️ Telegram DESACTIVADO (faltan credenciales)")
        else:
            logger.info("✅ Telegram ACTIVADO")
            # Verificar token al inicio
            self.test_connection()
    
    def test_connection(self) -> bool:
        """Verifica que el bot funcione"""
        try:
            test_url = f"https://api.telegram.org/bot{self.bot_token}/getMe"
            response = requests.get(test_url, timeout=10)
            if response.status_code == 200:
                bot_info = response.json()
                if bot_info.get('ok'):
                    username = bot_info['result'].get('username', 'unknown')
                    logger.info(f"✅ Conectado a bot: @{username}")
                    return True
            logger.error(f"❌ Error verificando bot Telegram: {response.text}")
            return False
        except Exception as e:
            logger.error(f"❌ Error en test_connection: {e}")
            return False
    
    def send_message(self, text: str, parse_mode: str = "HTML") -> bool:
        """
        Envía un mensaje a Telegram con reintentos.
        Retorna True si se envió correctamente.
        """
        if not self.enabled:
            logger.warning("Telegram desactivado, no se envía mensaje")
            return False
        
        for attempt in range(1, cfg.MAX_RETRIES + 1):
            try:
                response = requests.post(
                    self.api_url,
                    data={
                        'chat_id': self.chat_id,
                        'text': text,
                        'parse_mode': parse_mode,
                        'disable_web_page_preview': True,
                    },
                    timeout=cfg.TELEGRAM_TIMEOUT,
                )
                
                if response.status_code == 200:
                    result = response.json()
                    if result.get('ok'):
                        logger.info(f"✅ Mensaje Telegram enviado correctamente")
                        return True
                    else:
                        logger.error(f"❌ Telegram error: {result.get('description', 'unknown')}")
                else:
                    logger.error(f"❌ Telegram HTTP {response.status_code}: {response.text}")
                
            except requests.exceptions.Timeout:
                logger.warning(f"⏱️ Timeout en Telegram (intento {attempt})")
            except requests.exceptions.ConnectionError as e:
                logger.warning(f"🔌 Error de conexión Telegram (intento {attempt}): {e}")
            except Exception as e:
                logger.error(f"❌ Error inesperado Telegram (intento {attempt}): {e}")
            
            if attempt < cfg.MAX_RETRIES:
                time.sleep(cfg.RETRY_DELAY_SECONDS)
        
        logger.error(f"❌ Falló el envío después de {cfg.MAX_RETRIES} intentos")
        return False
    
    def send_signal(self, symbol: str, signal: dict) -> bool:
        """Envía una señal formateada a Telegram"""
        direction = signal['direction']
        emoji = "🟢" if direction == 'LONG' else "🔴"
        action = "COMPRA" if direction == 'LONG' else "VENTA"
        
        # Determinar nivel de calidad
        score = signal['score']
        if score >= 9.0:
            quality = "🏆 SEÑAL PERFECTA"
        elif score >= 8.0:
            quality = "⭐ SEÑAL EXCELENTE"
        elif score >= 7.0:
            quality = "✅ SEÑAL BUENA"
        else:
            quality = "📊 SEÑAL VÁLIDA"
        
        # Formatear precios según el símbolo
        if signal['entry'] > 1000:
            price_fmt = ",.2f"
        elif signal['entry'] > 1:
            price_fmt = ",.4f"
        else:
            price_fmt = ",.6f"
        
        confluences_str = " + ".join(signal['confluences'])
        
        from datetime import datetime
        timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
        
        text = (
            f"{emoji} <b>{direction}</b> | <b>{symbol}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"{quality}\n"
            f"📊 Score: <b>{signal['score']}/10</b>\n\n"
            f"💰 Entrada: <code>${signal['entry']:{price_fmt}}</code>\n"
            f"🛑 Stop Loss: <code>${signal['sl']:{price_fmt}}</code> (-{signal['sl_pct']}%)\n"
            f"🎯 TP1: <code>${signal['tp1']:{price_fmt}}</code> (+{signal['tp1_pct']}%)\n"
            f"🎯 TP2: <code>${signal['tp2']:{price_fmt}}</code> (+{signal['tp2_pct']}%)\n\n"
            f"📐 R:R → 1:{signal['rr']}\n"
            f"🔗 Confluencias: {confluences_str}\n\n"
            f"🕐 {timestamp}\n"
            f"⚠️ <i>Solo análisis técnico. No es consejo financiero.</i>"
        )
        
        return self.send_message(text)
    
    def send_startup(self, num_symbols: int) -> bool:
        """Envía mensaje de inicio del bot"""
        text = (
            f"📡 <b>Bot de Señales SMC v2 iniciado</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"📊 Monitoreando: {num_symbols} símbolos\n"
            f"⭐ Score mínimo: {cfg.SCORE_MIN_SIGNAL}/10\n"
            f"📐 R:R mínimo: 1:{cfg.MIN_RR}\n"
            f"⏱️ Loop: cada {cfg.LOOP_INTERVAL_SECONDS}s\n\n"
            f"✅ Listo para detectar señales de CALIDAD"
        )
        return self.send_message(text)
    
    def send_error(self, error_msg: str) -> bool:
        """Envía notificación de error"""
        text = (
            f"⚠️ <b>Error en Bot de Señales</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"<code>{error_msg}</code>\n\n"
            f"El bot continúa funcionando."
        )
        return self.send_message(text)
    
    def send_daily_summary(self, signals_sent: int, symbols_analyzed: int) -> bool:
        """Envía resumen diario"""
        from datetime import datetime
        today = datetime.utcnow().strftime("%Y-%m-%d")
        text = (
            f"📅 <b>Resumen Diario - {today}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"📊 Señales enviadas: <b>{signals_sent}</b>\n"
            f"🔍 Símbolos analizados: <b>{symbols_analyzed}</b>\n"
            f"⭐ Score mínimo: {cfg.SCORE_MIN_SIGNAL}/10\n\n"
            f"✅ Bot funcionando 24/7"
        )
        return self.send_message(text)
    
    def send_heartbeat(self, signals_count: int, symbols_count: int) -> bool:
        """Envía mensaje de estado cada cierto tiempo"""
        from datetime import datetime
        now = datetime.utcnow().strftime("%H:%M UTC")
        text = (
            f"💚 <b>Bot funcionando</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"🕐 {now}\n"
            f"📊 Señales hoy: {signals_count}\n"
            f"🔍 Símbolos: {symbols_count}\n"
            f"⭐ Score mín: {cfg.SCORE_MIN_SIGNAL}/10"
        )
        return self.send_message(text)
